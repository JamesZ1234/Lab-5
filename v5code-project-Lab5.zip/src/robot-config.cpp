#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor RoboticArm1_mJ1 = motor(PORT1, ratio18_1, false);
motor RoboticArm1_mJ2 = motor(PORT2, ratio18_1, true);
motor RoboticArm1_mJ3 = motor(PORT3, ratio18_1, false);
motor RoboticArm1_mJ4 = motor(PORT4, ratio18_1, false);
pot RoboticArm1_mJ1_pot = pot(Brain.ThreeWirePort.A);
pot RoboticArm1_mJ2_pot = pot(Brain.ThreeWirePort.B);
pot RoboticArm1_mJ3_pot = pot(Brain.ThreeWirePort.C);
pot RoboticArm1_mJ4_pot = pot(Brain.ThreeWirePort.D);
RoboticArm RoboticArm1 = RoboticArm(RoboticArm1_mJ1, RoboticArm1_mJ1_pot, RoboticArm1_mJ2, RoboticArm1_mJ2_pot, RoboticArm1_mJ3, RoboticArm1_mJ3_pot, RoboticArm1_mJ4, RoboticArm1_mJ4_pot);
bumper EStop = bumper(Brain.ThreeWirePort.E);

// VEXcode generated functions



/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}